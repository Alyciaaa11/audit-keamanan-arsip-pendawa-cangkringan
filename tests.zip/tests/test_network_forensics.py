import warnings
import numpy as np
import pandas as pd
import pytest

import network_forensics as nf

warnings.filterwarnings("ignore")
END = "2026-10-16"


@pytest.fixture(scope="module")
def raw():
    return nf.generate_simulated_logs(seed=42, end_date=END)


@pytest.fixture(scope="module")
def result(raw):
    return nf.analyze_logs(raw)


def test_simulation_is_deterministic(raw):
    again = nf.generate_simulated_logs(seed=42, end_date=END)
    pd.testing.assert_frame_equal(raw, again)
    other = nf.generate_simulated_logs(seed=7, end_date=END)
    assert not raw["IP_Address"].equals(other["IP_Address"])


def test_hour_distance():
    d = nf.hour_distance_outside(np.array([2.0, 8.0, 12.0, 18.0, 20.0, 23.5]), 8, 18)
    assert d.tolist() == [6.0, 0.0, 0.0, 0.0, 2.0, 5.5]


def test_burst_counts_only_same_ip_within_window():
    ts = pd.to_datetime(["2026-10-01 03:00:00", "2026-10-01 03:01:00", "2026-10-01 03:02:00",
                         "2026-10-01 03:03:00", "2026-10-01 09:00:00", "2026-10-01 03:01:30"])
    df = pd.DataFrame({"Timestamp": ts, "IP_Address": ["1.1.1.1"] * 4 + ["1.1.1.1", "2.2.2.2"],
                       "Status": ["Failed"] * 4 + ["Failed", "Failed"]}).sort_values("Timestamp").reset_index(drop=True)
    counts = nf.count_failures_nearby(df, 30)
    by = dict(zip(zip(df["IP_Address"], df["Timestamp"].dt.strftime("%H:%M:%S")), counts))
    assert by[("1.1.1.1", "03:00:00")] == 4
    assert by[("1.1.1.1", "09:00:00")] == 1
    assert by[("2.2.2.2", "03:01:30")] == 1


def test_normalise_aliases_and_status():
    df = pd.DataFrame({"waktu": ["2026-10-01 08:00", "2026-10-01 09:00"], "ip": ["10.0.0.1", "8.8.8.8"],
                       "aktivitas": ["Login", "Login"], "hasil": ["berhasil", "GAGAL"]})
    out, notes = nf.normalise_log_frame(df)
    assert out["Status"].tolist() == ["Success", "Failed"]
    assert {"Pengguna", "File_Accessed"} <= set(out.columns)


def test_normalise_errors():
    with pytest.raises(nf.LogValidationError):
        nf.normalise_log_frame(pd.DataFrame({"a": [1]}))
    bad = pd.DataFrame({"Timestamp": ["2026-10-01"], "IP_Address": ["1.1.1.1"], "User_Action": ["x"], "Status": ["maybe"]})
    with pytest.raises(nf.LogValidationError):
        nf.normalise_log_frame(bad)
    with pytest.raises(nf.LogValidationError):
        nf.normalise_log_frame(pd.DataFrame())


def test_invalid_timestamps_dropped_with_note():
    df = pd.DataFrame({"Timestamp": ["2026-10-01 08:00", "bukan tanggal"], "IP_Address": ["1.1.1.1"] * 2,
                       "User_Action": ["Login"] * 2, "Status": ["Success"] * 2})
    out, notes = nf.normalise_log_frame(df)
    assert len(out) == 1 and any("tidak valid" in n for n in notes)


def test_scan_outputs_are_readable(result):
    logs = result.logs
    assert result.summary["total_events"] == len(logs)
    assert 0 < result.summary["n_anomalies"] < 0.1 * len(logs)
    assert set(logs["Prioritas"]) <= set(nf.PRIORITY_ORDER)
    an = logs[logs["Is_Anomaly"]]
    assert (an["Alasan"].str.len() > 0).all()
    assert (an["Skor_Anomali"] > result.threshold - 1e-9).all()
    assert (logs.loc[~logs["Is_Anomaly"], "Alasan"] == "").all()
    contrib = result.contributions.loc[an.index]
    assert contrib.notna().all().all()
    assert np.allclose(contrib.sum(axis=1), 1.0) or (contrib.sum(axis=1) == 0).any()
    assert not logs[["Timestamp", "IP_Address", "User_Action", "Status", "Indikator"]].isna().any().any()


def test_model_does_not_see_ground_truth(result):
    assert not any(c.startswith("Sim_") for c in result.feature_matrix.columns)


def test_detects_injected_scenarios(result):
    logs = result.logs
    brute = logs[logs["Sim_Skenario"] == nf.SIM_BRUTE]
    assert brute["Is_Anomaly"].mean() > 0.9
    night = logs[logs["Sim_Skenario"] == nf.SIM_NIGHT]
    assert (night["Jumlah_Indikator"] >= 2).all()
    assert night["Flag_Luar_Jam"].all()
    foreign = logs[logs["Sim_Skenario"] == nf.SIM_FOREIGN]
    assert foreign["Flag_IP_Tidak_Biasa"].all()
    assert foreign["Prioritas"].isin(["Sedang", "Tinggi"]).all()
    normal = logs[logs["Sim_Skenario"] == nf.SIM_NORMAL]
    assert normal["Is_Anomaly"].mean() < 0.01
    ev = nf.evaluate_against_simulation(logs)
    assert ev["prioritas_sedang_ke_atas"]["recall"] >= 0.95
    assert ev["isolation_forest"]["precision"] >= 0.9


def test_scan_is_reproducible(raw, result):
    again = nf.analyze_logs(raw)
    assert again.logs["Is_Anomaly"].equals(result.logs["Is_Anomaly"])


def test_parameters_validated(raw):
    with pytest.raises(nf.LogValidationError):
        nf.analyze_logs(raw, op_start=18, op_end=8)
    with pytest.raises(nf.LogValidationError):
        nf.analyze_logs(raw, contamination=0.9)
    with pytest.raises(nf.LogValidationError):
        nf.analyze_logs(raw, trusted_networks="bukan-cidr")
    with pytest.raises(nf.LogValidationError):
        nf.analyze_logs(raw.head(10))


def test_trusted_networks_change_ip_flag(raw):
    strict = nf.analyze_logs(raw, trusted_networks="192.168.1.0/24")
    assert strict.logs["Flag_IP_Tidak_Biasa"].sum() >= 0
    none_trusted = nf.analyze_logs(raw, trusted_networks="")
    assert none_trusted.logs["Flag_IP_Tidak_Biasa"].all()


def test_filters(result):
    logs = result.logs
    assert len(nf.apply_filters(logs)) == len(logs)
    assert nf.apply_filters(logs, anomaly_mode="Hanya anomali")["Is_Anomaly"].all()
    assert not nf.apply_filters(logs, anomaly_mode="Hanya normal")["Is_Anomaly"].any()
    assert set(nf.apply_filters(logs, statuses=["Failed"])["Status"]) == {"Failed"}
    assert set(nf.apply_filters(logs, actions=["Login"])["User_Action"]) == {"Login"}
    assert nf.apply_filters(logs, actions=[]).empty
    hr = nf.apply_filters(logs, hour_range=(0, 4))
    assert hr["Timestamp"].dt.hour.max() <= 4
    d0 = logs["Timestamp"].min().date()
    one_day = nf.apply_filters(logs, date_range=(d0, d0))
    assert (one_day["Timestamp"].dt.date == d0).all() and len(one_day) > 0
    assert len(nf.apply_filters(logs, date_range=(d0,))) == len(one_day)
    ind = nf.apply_filters(logs, indicators=["Gagal beruntun"])
    assert ind["Flag_Gagal_Beruntun"].all()
    ip = logs["IP_Address"].iloc[0]
    assert (nf.apply_filters(logs, query=ip)["IP_Address"] == ip).any()
    combo = nf.apply_filters(logs, statuses=["Failed"], anomaly_mode="Hanya anomali", indicators=["Gagal beruntun"])
    assert (combo["Status"] == "Failed").all() and combo["Is_Anomaly"].all()
