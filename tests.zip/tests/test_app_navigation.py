import os
import warnings
from streamlit.testing.v1 import AppTest

warnings.filterwarnings("ignore")
APP = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app.py")
PAGES = ["Dashboard", "Digital Archive & Integrity", "Production Analytics", "Network Log Forensics", "Settings"]


def goto(at, page):
    at.sidebar.radio(key="main_navigation").set_value(page).run()
    assert not at.exception, [e.value for e in at.exception]


def new_app():
    at = AppTest.from_file(APP, default_timeout=120)
    at.run()
    assert not at.exception, [e.value for e in at.exception]
    return at


def test_all_pages_load_and_switch_repeatedly():
    at = new_app()
    for _ in range(2):
        for page in PAGES:
            goto(at, page)


def test_scan_goes_to_dashboard_notifications_only():
    at = new_app()
    goto(at, "Network Log Forensics")
    notes = at.session_state["dashboard_notifications"]
    net = [n for n in notes if "Pemindaian jaringan" in n["message"]]
    assert len(net) == 1 and "simulasi" in net[0]["message"]
    # tidak ada riwayat notifikasi terpisah untuk jaringan
    assert not [k for k in at.session_state.keys() if "notif" in str(k) and k not in ("dashboard_notifications", "show_notifications", "header_notifications")]
    # filter / pindah menu tidak menambah notifikasi
    goto(at, "Dashboard")
    goto(at, "Network Log Forensics")
    assert len([n for n in at.session_state["dashboard_notifications"] if "Pemindaian jaringan" in n["message"]]) == 1
    goto(at, "Dashboard")
    text = " ".join(m.value for m in at.markdown)
    assert "Pemindaian jaringan nomor 1" in text
    assert any("simulasi" in c.value for c in at.caption)


def test_simulation_banner_present():
    at = new_app()
    goto(at, "Network Log Forensics")
    assert any("MODE SIMULASI" in w.value for w in at.warning)
    assert not any("Safe" in str(m.delta) for m in at.metric)


def test_filters_work_and_persist_across_menus():
    at = new_app()
    goto(at, "Network Log Forensics")
    total = int(at.session_state["network_scan"].summary["total_events"])
    status = [m for m in at.multiselect if m.label.startswith("Status")][0]
    status.set_value(["Failed"]).run()
    assert not at.exception
    cap = [c.value for c in at.caption if "Menampilkan" in c.value][0]
    n_failed = int(at.session_state["network_scan"].summary["n_failed"])
    assert f"**{n_failed:,}** dari {total:,}" in cap
    mode = [r for r in at.radio if r.label == "Status anomali"][0]
    mode.set_value("Hanya anomali").run()
    assert not at.exception
    goto(at, "Settings")
    goto(at, "Network Log Forensics")
    status = [m for m in at.multiselect if m.label.startswith("Status")][0]
    assert status.value == ["Failed"]
    assert [r for r in at.radio if r.label == "Status anomali"][0].value == "Hanya anomali"
    # reset
    [b for b in at.button if b.key == "net_reset_filters"][0].click().run()
    assert not at.exception
    assert [r for r in at.radio if r.label == "Status anomali"][0].value == "Semua"


def test_empty_filter_result_does_not_crash():
    at = new_app()
    goto(at, "Network Log Forensics")
    [m for m in at.multiselect if m.label == "Jenis aktivitas"][0].set_value([]).run()
    assert not at.exception
    [m for m in at.multiselect if m.label == "Jenis aktivitas"][0].set_value(["Login"]).run()
    [r for r in at.radio if r.label == "Status anomali"][0].set_value("Hanya normal").run()
    [m for m in at.multiselect if m.label.startswith("Hanya yang")][0].set_value(["Gagal beruntun"]).run()
    assert not at.exception


def test_rescan_with_new_settings_adds_new_notification():
    at = new_app()
    goto(at, "Network Log Forensics")
    [s for s in at.slider if s.label.startswith("Sensitivitas")][0].set_value(6).run()
    [b for b in at.button if b.key == "net_run_scan"][0].click().run()
    assert not at.exception
    net = [n for n in at.session_state["dashboard_notifications"] if "Pemindaian jaringan" in n["message"]]
    assert len(net) == 2 and "nomor 2" in net[-1]["message"]
    assert at.session_state["dashboard_network_anomalies"] == at.session_state["network_scan"].summary["n_anomalies"]


def test_upload_source_without_file_shows_error_not_crash():
    at = new_app()
    goto(at, "Network Log Forensics")
    [r for r in at.radio if r.label == "Sumber data log"][0].set_value("Unggah log CSV/Excel").run()
    [b for b in at.button if b.key == "net_run_scan"][0].click().run()
    assert not at.exception
    assert any("Belum ada file log" in e.value for e in at.error)
